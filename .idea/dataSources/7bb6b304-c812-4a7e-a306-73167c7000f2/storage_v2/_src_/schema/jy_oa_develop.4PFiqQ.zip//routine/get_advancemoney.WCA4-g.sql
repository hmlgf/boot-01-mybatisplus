create
    definer = root@localhost function get_advancemoney(_cusid bigint) returns int
BEGIN
	DECLARE _advancemoney INT ;
	SELECT IFNULL(SUM(totalamount),0) INTO _advancemoney FROM crm_contract_moneylog 
	WHERE contractid=0 and approvalstatus != 3 AND cusid=_cusid;
	RETURN _advancemoney;
END;

