create
    definer = root@`%` function get_certContractNumber(_type int) returns varchar(20)
BEGIN
    
    -- 函数中用到的参数定义
    DECLARE contract_number varchar(20);  -- 合同编号
    DECLARE contract_count int; -- 合同数量
    DECLARE contract_title varchar(20) default 'RC';
    
    select count(1) into contract_count from certificate_contract_info where type = _type and DATE_FORMAT(NOW(),"%Y-%m-%d")= DATE_FORMAT(createdate,"%Y-%m-%d");
    
    IF (_type = 1) THEN
        SELECT 'QY' INTO contract_title;
    ELSEIF (_type = 2) THEN
	SELECT 'ZJRC' INTO contract_title;
    ELSEIF (_type = 3) THEN
	SELECT 'ZJQY' INTO contract_title;
    ELSEIF (_type = 4) THEN
	SELECT 'ZZQY' INTO contract_title;
    ELSEIF (_type = 5) THEN
	SELECT 'ZJZZQY' INTO contract_title;
    END IF;
    
    IF (contract_count > 0) THEN
        SELECT 
            CONCAT(contract_title,'-',SUBSTRING_INDEX(number,'-',-1)+1) INTO contract_number 
        FROM certificate_contract_info 
        WHERE TYPE = _type AND DATE_FORMAT(NOW(),"%Y-%m-%d")= DATE_FORMAT(createdate,"%Y-%m-%d") 
        ORDER BY createdate DESC
        LIMIT 0,1;
    ELSE 
        SELECT CONCAT(contract_title,'-',DATE_FORMAT(NOW(),"%Y%m%d"),'001') INTO contract_number;
    END IF;
    
    return contract_number;
    
END;

