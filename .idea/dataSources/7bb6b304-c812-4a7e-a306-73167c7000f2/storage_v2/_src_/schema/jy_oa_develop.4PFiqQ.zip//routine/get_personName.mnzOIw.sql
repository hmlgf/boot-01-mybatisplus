create
    definer = root@localhost function get_personName(_personid bigint) returns varchar(50)
BEGIN
DECLARE personName VARCHAR(20) CHARSET utf8 ; -- 拥有人
SELECT a.name INTO personName FROM person_info a WHERE a.id = _personid;
RETURN personName;
END;

