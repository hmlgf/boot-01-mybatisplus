create
    definer = root@localhost function get_totalmoney(_cusid bigint, _contractid bigint) returns int
BEGIN
	DECLARE _totalmoey int ; -- 拥有人
	SELECT SUM(totalamount) INTO _totalmoey FROM crm_contract_moneylog WHERE state =1 AND approvalstatus != 3 AND cusid = _cusid AND contractid =_contractid;
	RETURN _totalmoey;
    END;

