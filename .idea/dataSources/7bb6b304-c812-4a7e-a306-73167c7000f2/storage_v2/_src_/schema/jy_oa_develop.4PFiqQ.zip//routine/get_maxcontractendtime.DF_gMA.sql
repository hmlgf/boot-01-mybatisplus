create
    definer = root@localhost function get_maxcontractendtime(_cusid bigint) returns datetime
BEGIN
	DECLARE _maxcontractendtime DATETIME;
	SELECT endtime INTO _maxcontractendtime FROM crm_contract
	WHERE TYPE=0 AND cusid=_cusid AND isdel = 0 AND isadditional = 0
	ORDER BY createdate DESC LIMIT 0,1;
	RETURN _maxcontractendtime;
END;

