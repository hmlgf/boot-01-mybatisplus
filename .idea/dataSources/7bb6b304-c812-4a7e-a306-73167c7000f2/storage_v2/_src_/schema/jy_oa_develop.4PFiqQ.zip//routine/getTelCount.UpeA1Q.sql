create
    definer = root@localhost function getTelCount(_id bigint, _keyword varchar(500)) returns int
BEGIN
       DECLARE size INT DEFAULT 0;
        SELECT COUNT(1) INTO size FROM crm_customer_contacts   WHERE   (POSITION( _keyword in tel) OR POSITION( _keyword in phone)) AND isdel =0 AND  cusid=_id; 
        
       RETURN size;
    END;

