create
    definer = root@localhost function get_dynamicstate(_id bigint) returns int
BEGIN
           -- 查询预约状态
	   DECLARE dstate INT DEFAULT 99; -- 待预约  99待预约,0 已预约  2 已联系  3 需要紧急联系
	   DECLARE tempstate INT DEFAULT -1; -- 临时预约状态
	   DECLARE days INT DEFAULT 0;
	   SELECT  state ,(TO_DAYS(DATE_FORMAT(updatedate,'%Y-%m-%d'))-TO_DAYS(DATE_FORMAT(NOW(),'%Y-%m-%d')) )  INTO tempstate, days FROM `crm_customer_info`  WHERE id =_id;
	   IF (days<0) THEN
		BEGIN
		     if (tempstate=1 and days <= -30) then   -- 意向不明 30天提醒
			SET dstate =  3;	
		     end if;
		     IF (tempstate=2  AND days <= -30) THEN   -- 即将到期 30天提醒
			SET dstate =  3;	
		     END IF;
		     IF (tempstate=3  AND days <= -30) THEN  -- 随时可挂 30天提醒
			SET dstate =  3;	
		     END IF;
		     IF (tempstate=4  AND days <= -100) THEN  -- 公共库 30天提醒
			SET dstate =  3;	
		     END IF;
		     IF (tempstate=5  AND days <= -30) THEN  -- 有证就办 30天提醒
			SET dstate =  3;	
		     END IF; 	
		     IF (tempstate=6  AND days <= -30) THEN  -- 将要聘证 30天提醒
			SET dstate =  3;	
		     END IF; 
		     IF (tempstate=7  AND days <= -180) THEN  -- 合作客户 180天提醒
			SET dstate =  3;	
		     END IF; 		
		end;
	   end if;
	   if (dstate=99) THEN
		begin
		   set tempstate = -1;
		   SELECT  state  INTO tempstate FROM crm_contacts_dynamic_info   WHERE  DATE_FORMAT(stime,'%Y-%m-%d') >= DATE_FORMAT(NOW(),'%Y-%m-%d') AND state=2   AND cusid = _id  AND ISNULL(showstate) LIMIT 0,1 ; 
		   IF (tempstate>-1) THEN  
		      SET dstate =  tempstate;
		   ELSE
			SELECT  state  INTO tempstate FROM crm_contacts_dynamic_info   WHERE  DATE_FORMAT(stime,'%Y-%m-%d') >= DATE_FORMAT(NOW(),'%Y-%m-%d')   AND cusid = _id  AND ISNULL(showstate) LIMIT 0,1 ;
			 IF (tempstate>-1) THEN  
			   SET dstate =  tempstate;
			 END IF;
		   END IF; 
		END;   
	   end if;   
	   
	
	   RETURN dstate;
    END;

