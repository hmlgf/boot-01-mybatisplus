create
    definer = root@localhost function get_newcreatedate(_cusid bigint) returns datetime
BEGIN
	DECLARE _newcreatedate DATETIME;
	SELECT MAX(createdate) INTO _newcreatedate FROM crm_contacts_dynamic_info 
	WHERE state=2 AND cusid=_cusid;
	RETURN _newcreatedate;
END;

