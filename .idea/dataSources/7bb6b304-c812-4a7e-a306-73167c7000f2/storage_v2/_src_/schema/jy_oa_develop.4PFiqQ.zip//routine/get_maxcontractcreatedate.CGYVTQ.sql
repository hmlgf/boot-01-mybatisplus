create
    definer = root@localhost function get_maxcontractcreatedate(_cusid bigint) returns datetime
BEGIN
	DECLARE _maxcontractcreatedate DATETIME;
	SELECT createdate INTO _maxcontractcreatedate FROM crm_contract
	WHERE type=0 AND cusid=_cusid and isdel = 0 and isadditional = 0
	order by createdate DESC limit 0,1;
	RETURN _maxcontractcreatedate;
END;

