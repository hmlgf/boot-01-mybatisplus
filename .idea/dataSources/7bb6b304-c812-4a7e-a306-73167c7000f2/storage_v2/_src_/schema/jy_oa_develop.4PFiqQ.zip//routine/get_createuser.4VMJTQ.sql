create
    definer = root@localhost function get_createuser(_createuser bigint) returns varchar(50)
BEGIN
DECLARE createusersname VARCHAR(20) CHARSET utf8 ; -- 拥有人
SELECT a.name INTO createusersname FROM `user_info` a WHERE a.uid = _createuser;
RETURN createusersname;
END;

