create
    definer = root@localhost function get_searchstate(_id int, _keyword varchar(200)) returns int
BEGIN
	   DECLARE _totalsize INT DEFAULT 0; -- 总条数
	   DECLARE _state INT default 0 ; -- 状态 0 未查询出  1 已查询出
	 
           select count(1) into _totalsize from `crm_contacts_dynamic_info`  where remark like   concat('%',_keyword,'%') AND cusid =_id  ;
           if (_totalsize>0) then
		set _state =1;
           end if;
           return _state;
    END;

