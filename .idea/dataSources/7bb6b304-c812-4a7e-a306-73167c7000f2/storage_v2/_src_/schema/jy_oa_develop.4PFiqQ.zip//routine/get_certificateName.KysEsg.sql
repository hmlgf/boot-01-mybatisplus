create
    definer = root@localhost function get_certificateName(_certificate varchar(50)) returns varchar(100)
BEGIN
DECLARE certificatename VARCHAR(100) CHARSET utf8 ; -- 定义返回值证书名
SELECT LEFT(_certificate, LENGTH(_certificate)-1) INTO _certificate; -- 去除传入参数后的逗号
SELECT GROUP_CONCAT(CONCAT(b.name,'-',c.name) SEPARATOR ',') INTO certificatename FROM 
(
	SELECT
	SUBSTRING_INDEX(SUBSTRING_INDEX(_certificate,',',id),',',-1) AS two,
	CONCAT(LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(_certificate,',',id),',',-1), 2),'000') AS ONE
	FROM customer_info_certificate
	WHERE id <= LENGTH(_certificate)-LENGTH(REPLACE(_certificate,',',''))+1
) a 
LEFT JOIN sys_certificate_configure b ON a.one = b.code
LEFT JOIN sys_certificate_configure c ON a.two = c.code;
RETURN certificatename;
END;

