create
    definer = root@localhost function get_contractsigning(_contractid bigint, _cusid bigint) returns int
BEGIN
	 DECLARE csize INT ;
	 SELECT COUNT(1) INTO csize  FROM crm_contract_moneylog WHERE contractid !=_contractid  AND cusid=_cusid;
	 RETURN csize;
    END;

