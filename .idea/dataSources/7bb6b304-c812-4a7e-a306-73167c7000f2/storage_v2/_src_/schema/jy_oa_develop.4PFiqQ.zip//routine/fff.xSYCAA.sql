create
    definer = root@localhost function fff() returns int
BEGIN
         return 1;
    END;

