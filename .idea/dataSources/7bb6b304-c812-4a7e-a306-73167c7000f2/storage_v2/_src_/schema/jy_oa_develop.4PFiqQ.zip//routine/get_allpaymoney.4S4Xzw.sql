create
    definer = root@localhost function get_allpaymoney(_contractid bigint) returns int
BEGIN
	DECLARE _allpaymoey INT ;
	
	DECLARE _oldpaymoney INT ;
	DECLARE _newpaymoney INT ;
	
	
	
	SELECT COALESCE(SUM(totalamount),0) INTO _oldpaymoney FROM crm_contract_moneylog 
	WHERE TYPE =1 AND approvalstatus = 2 AND contractid = _contractid;
	
	SELECT COALESCE(SUM(paymoney),0) INTO _newpaymoney FROM crm_contract_moneylog_log
	WHERE isdel = 0 AND approvalstatus = 2 AND conid = _contractid;
	SET _allpaymoey = _oldpaymoney + _newpaymoney;
	
	RETURN _allpaymoey;
END;

